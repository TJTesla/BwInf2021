public class QuerstehendesAuto
{
    String vBezeichnung;
    int vPosition;
    public QuerstehendesAuto (String pBezeichnung, int pPosition)
    {
        vBezeichnung = pBezeichnung;
        vPosition = pPosition;
    }
    public String getBezeichnung()
    {
        return vBezeichnung;
    }
    public int getPosition()
    {
        return vPosition;
    }
}

